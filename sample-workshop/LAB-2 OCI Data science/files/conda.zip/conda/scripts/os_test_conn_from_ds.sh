#
# Testing connection to OCI Opensearch instance from OCI Data science service
#
curl -k -u <os_userid>:<os_password> <os_api_endpoint> :9200
