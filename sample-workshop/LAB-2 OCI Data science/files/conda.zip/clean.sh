rm -Rf ~/conda/data
rm -Rf ~/conda/outputs
rm -Rf ~/conda/templates
rm -Rf ~/conda/scripts
rm ~/conda/notebooks/demo*.ipynb
rm -f conda.zip
