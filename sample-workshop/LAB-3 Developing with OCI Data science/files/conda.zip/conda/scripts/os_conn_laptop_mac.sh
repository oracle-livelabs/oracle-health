#
# For connecting to OCI Opensearch dasghboard from local machine, you need to first SSH with port forwarding of the 
# Opensearch dashboard IP and the API IP with corresponding ports to the instance
# You would also need the public IP and the SSH key for connecting to the instance 
#
ssh -C -v -t -L 127.0.0.1:5601:<os_dashboard_pvt_ip>:5601 -L 127.0.0.1:9200:<os_API_private_ip>:9200 opc@<public ip for compute instance> -i <ssh_key>